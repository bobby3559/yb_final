from django.contrib import admin

from ybstore.models import *


class Giftcard_Denomination_Configuration(admin.TabularInline):
    model = Giftcard_Denomination

class Giftcard_Configuration(admin.ModelAdmin):
    inlines = [ Giftcard_Denomination_Configuration ]

admin.site.register(Giftcard , Giftcard_Configuration)
admin.site.register(Giftcard_category)
admin.site.register(Profile)
admin.site.register(Carousel)
admin.site.register(BrandsCarousel)
admin.site.register(Web_contact_info)
admin.site.register(Web_logos)


