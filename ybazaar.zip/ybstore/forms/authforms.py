from django.contrib.auth.forms import UserCreationForm , AuthenticationForm
from django import forms
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError



class CustomerAuthForm(AuthenticationForm):
    username = forms.EmailField(required=True , label="Email" , 
            error_messages={
            'required': 'Please enter your email address.',
            'invalid': 'Please enter a valid email address.',
        })












class CustomerCreationForm(UserCreationForm):
    username = forms.EmailField(required=True , label="Email" , 
            error_messages={
            'required': 'Please enter your email address.',
            'invalid': 'Please enter a valid email address.',
            'unique': 'This email address is already in use.',
        })
    first_name = forms.CharField(max_length=150, required=True , label = 'Full Name')
    

    def clean_first_name(self):
        value = self.cleaned_data.get('first_name')
        if len(value.strip()) < 4 :
            raise ValidationError("Full Name must be 4 char long...")
        return value.strip()






    class Meta:
        model = User
        fields = ['username' , 'first_name']
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Remove help text from specific fields
        self.fields['username'].help_text = ''  # Remove help text for 'username' field
        self.fields['password1'].help_text = ''  # Remove help text for 'password1' field
        self.fields['password2'].help_text = ''  # Remove help text for 'password2' field

