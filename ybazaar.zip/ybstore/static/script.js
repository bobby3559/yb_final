
// logos-slide clone script code

var copy = document.querySelector(".logos-slide").cloneNode(true);
document.querySelector('.logos').appendChild(copy);



// View More JavaScript to toggle the visibility of additional products
const viewMoreBtn = document.getElementById("viewMoreBtn");
const hiddenProducts = document.querySelectorAll(".hidden");

viewMoreBtn.addEventListener("click", function () {
    hiddenProducts.forEach((product) => {
        product.style.display = "block";
    });
    viewMoreBtn.style.display = "none"; // Hide the "View More" button
});




// Main slider Javascript
const slider = document.querySelector(".slider");
const images = document.querySelectorAll(".slider-image");
let currentIndex = 0;

function nextSlide() {
    currentIndex = (currentIndex + 1) % images.length;
    updateSlider();
}

function prevSlide() {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    updateSlider();
}

function updateSlider() {
    const translateXValue = -currentIndex * 100; // Calculate the translation value
    slider.style.transform = `translateX(${translateXValue}%)`;
}

// Auto-slide every 2 seconds
setInterval(() => {
    nextSlide();
}, 3000);





// Hide Show customer details code
function hideShowDiv(val) {
    if (val == 1) {
        document.getElementById('customer-details').style.display = 'none';
    }
    if (val == 2) {
        document.getElementById('customer-details').style.display = 'block';
    }
}



// Hide Show receiver's details code
function hideShowForm(val) {
    if (val == 1) {
        document.getElementById('phone-receiver-form').style.display = 'none';
        document.getElementById('sender-receiver-form').style.display = 'none';
        document.getElementById('mail-receiver-form').style.display = 'block';
    }
    if (val == 2) {
        document.getElementById('phone-receiver-form').style.display = 'block';
        document.getElementById('sender-receiver-form').style.display = 'none';
        document.getElementById('mail-receiver-form').style.display = 'none';
    }
    if (val == 3) {
        document.getElementById('phone-receiver-form').style.display = 'none';
        document.getElementById('sender-receiver-form').style.display = 'block';
        document.getElementById('mail-receiver-form').style.display = 'none';
    }
}



// Hide Show description details code
function hideShowdes(val) {
    if (val == 1) {
        document.getElementById('giftcard-description').style.display = 'block';
        document.getElementById('giftcard-Terms-conditions').style.display = 'none';
        document.getElementById('giftcard-how-to-redeem').style.display = 'none';
    }
    if (val == 2) {
        document.getElementById('giftcard-description').style.display = 'none';
        document.getElementById('giftcard-Terms-conditions').style.display = 'block';
        document.getElementById('giftcard-how-to-redeem').style.display = 'none';
    }
    if (val == 3) {
        document.getElementById('giftcard-description').style.display = 'none';
        document.getElementById('giftcard-Terms-conditions').style.display = 'none';
        document.getElementById('giftcard-how-to-redeem').style.display = 'block';
    }
}


// Quantity increment and decrement buttons code
function increasecount(a, b) {
    var input = b.previousElementSibling;
    var value = parseInt(input.value, 10);
    if (value < 10) {
        value = isNaN(value) ? 0 : value;
        value++;
        input.value = value;
    }
}

function decreasecount(a, b) {
    var input = b.nextElementSibling;
    var value = parseInt(input.value, 10);
    if (value > 1) {
        value = isNaN(value) ? 0 : value;
        value--;
        input.value = value;
    }
}