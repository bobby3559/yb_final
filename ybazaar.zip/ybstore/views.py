from django.http import JsonResponse
from django.shortcuts import render , redirect , HttpResponse
from ybstore.forms.authforms import CustomerCreationForm , CustomerAuthForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.contrib.auth import authenticate , login as loginUser , logout as signout
from ybstore.models import *

def home(request):
    slider_images = Carousel.objects.all()

    giftcard_categories = Giftcard_category.objects.all()

    Brands_slider = BrandsCarousel.objects.all()

    active_products = Giftcard.objects.filter(Product_status="active")

    top_selling = active_products.filter(section='top_deals')

    hide_products = active_products.filter(section='hidden_products')

    best_selling = active_products.filter(section='top_offers')
    
    context = {
        "top_selling": top_selling,
        "hide_products": hide_products,
        "best_selling": best_selling,
        "slider_images": slider_images,
        "giftcard_categories": giftcard_categories,
        "Brands_slider": Brands_slider,
    }
    return render( request , template_name='store/index.html',context=context)

def giftcard_category(request, category_id):
    slider_images = Carousel.objects.all()

    giftcard_categories = Giftcard_category.objects.all()

    Brands_slider = BrandsCarousel.objects.all()

    category = Giftcard_category.objects.get(pk=category_id)

    active_products = Giftcard.objects.filter(Product_status="active")

    filtered_products = active_products.filter(Giftcard_category=category)

    best_selling = active_products.filter(section='top_offers')

    context = {
        "slider_images": slider_images,
        "giftcard_categories": giftcard_categories,
        'category': category,
        "filtered_products":filtered_products,
        'best_selling': best_selling,
        'Brands_slider': Brands_slider,
    }
    return render(request, 'store/giftcard_category.html', context)



def giftcard_details(request , giftcard_id):

    giftcard_detail = Giftcard.objects.get(pk=giftcard_id)

    denomination = request.GET.get("denomination")
    if denomination is None:
        denomination  = giftcard_detail.giftcard_denomination_set.all().order_by('price').first()
    else:
        denomination = giftcard_detail.giftcard_denomination_set.get(Denomination=denomination)
    


    context = {
        "giftcard_detail": giftcard_detail,
        "active_denomination": denomination,
    }

    return render(request, 'store/giftcard_details.html', context)




def profile(request):
    context = {}
    check = Profile.objects.filter(user__id=request.user.id)
    if len(check)>0:
        data = Profile.objects.get(user__id=request.user.id)
        context = {
            'data': data
        }
    return render( request , template_name='store/profile.html',context=context)

def edit_profile(request):
    check = Profile.objects.filter(user__id=request.user.id)
    if len(check)>0:
        data = Profile.objects.get(user__id=request.user.id)
        context = {
            'data': data
        }
    if request.method=='POST':
        f_name = request.POST["first_name"]
        d_o_b = request.POST["dob"]
        address_1 = request.POST["address_line_1"]
        address_2 = request.POST["address_line_2"]
        cty = request.POST["city"]
        pin_code = request.POST["postal_code"]
        stat = request.POST["state"]

        usr = User.objects.get(id=request.user.id)
        usr.first_name = f_name
        usr.save()


        data.dob = d_o_b
        data.address_line_1 = address_1
        data.address_line_2 = address_2
        data.city = cty
        data.postal_code = pin_code
        data.state = stat
        data.save()
        messages.success(request , f'Your account has been updated!')
        context = {
            'data': data
        }
        return render( request , template_name='store/profile.html' , context=context)
    
    return render( request , template_name='store/edit_profile.html' , context=context)

def account(request):

    return render( request , template_name='store/account.html')


def login(request):
    if request.method == 'GET':
        form = CustomerAuthForm
        return render( request , template_name='store/login.html' , context={ 'form' : form })
    
    else:
        form = CustomerAuthForm(data = request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username = username , password = password)
            if user:
                loginUser(request , user)
                return redirect('home')
            
        else:
            return render( request , template_name='store/login.html' , context={ 'form' : form })




def register(request):
    if (request.method == 'GET'):
        form = CustomerCreationForm()
        context = {
            "form": form
        }
        return render( request , template_name='store/register.html' , context=context)
    
    else:
        form = CustomerCreationForm(request.POST)
        m_no = request.POST["Mobile_No"]
        if form.is_valid():
            usr = form.save();
            usr.email = usr.username
            usr.save()

            profile = Profile(user=usr , Mobile_No = m_no)
            profile.save()
            messages.success(request , 'Account registered successfully. Please')
            context = {
            "form": form
            }
            return render( request , template_name='store/register.html' , context=context)
        context = {
            "form": form
        }
        return render( request , template_name='store/register.html' , context=context)
        
def logout(request):

    signout(request)

    slider_images = Carousel.objects.all()

    giftcard_categories = Giftcard_category.objects.all()
    
    Brands_slider = BrandsCarousel.objects.all()

    active_products = Giftcard.objects.filter(Product_status="active")

    top_selling = active_products.filter(section='top_deals')

    hide_products = active_products.filter(section='hidden_products')

    best_selling = active_products.filter(section='top_offers')
    
    context = {
        "top_selling": top_selling,
        "hide_products": hide_products,
        "best_selling": best_selling,
        "slider_images": slider_images,
        "giftcard_categories": giftcard_categories,
        "Brands_slider": Brands_slider,
    }

    
    return render( request , template_name='store/index.html' , context=context)


def productlistAjax(request):

    active_products = Giftcard.objects.filter(Product_status="active").values_list('name', flat=True)

    giftcard_list = list(active_products)

    return JsonResponse(giftcard_list , safe=False)

def searchgiftcard(request):
    if request.method == 'POST':
        searchedterm = request.POST.get('giftcardsearch')
        if searchedterm == '':
            return redirect(request.META.get('HTTP_REFERER'))
        else:
            active_giftcard = Giftcard.objects.filter(Product_status="active")
            searchedgift = active_giftcard.filter(name__contains=searchedterm).first()

            if searchedgift:
                return redirect('giftcard/'+str(searchedgift.id))
            else:
                messages.info(request,"No GiftCard matched your search")
                return redirect(request.META.get('HTTP_REFERER'))

    return redirect(request.META.get('HTTP_REFERER'))

def Contact_Us(request):
    website_logos = Web_logos.objects.all()
    website_contact_details = Web_contact_info.objects.all()
    context ={
        'website_contact_details': website_contact_details,
        'website_logos': website_logos,
    }
    return render( request , template_name='store/contact_us.html' , context=context)

def TermsConditions(request):

    return render( request , template_name='store/terms_conditions.html')

def PrivacyPolicy(request):

    return render( request , template_name='store/privacy_policy.html')